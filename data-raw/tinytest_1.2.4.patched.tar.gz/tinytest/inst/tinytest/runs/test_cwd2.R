
old <- getwd()
setwd(tempdir())
setwd(old)

